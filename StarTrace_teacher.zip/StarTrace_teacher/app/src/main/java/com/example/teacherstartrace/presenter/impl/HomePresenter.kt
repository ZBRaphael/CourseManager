package com.example.teacherstartrace.presenter.impl

/**
 * ClassName:HomePresenter
 * Created bu ZhangBo at 2020/6/20
 * Describe:
 **/
interface HomePresenter {
}