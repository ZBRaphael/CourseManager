package com.example.teacherstartrace.presenter.interf

import com.example.teacherstartrace.presenter.impl.HomePresenter
import com.example.teacherstartrace.view.HomeView

/**
 * ClassName:HomePresenterImpl
 * Created bu ZhangBo at 2020/6/20
 * Describe:
 **/
class HomePresenterImpl(var homeView: HomeView):
    HomePresenter {

}