package com.example.teacherstartrace.ui.activity


import com.example.teacherstartrace.R
import com.example.teacherstartrace.base.BaseActivity

/**
 * ClassName:AboutActivity
 * Created bu ZhangBo at 2020/6/16
 * Describe:
 **/
class AboutActivity: BaseActivity() {
    override fun getLayoutId(): Int {
        return R.layout.activity_about
    }


}