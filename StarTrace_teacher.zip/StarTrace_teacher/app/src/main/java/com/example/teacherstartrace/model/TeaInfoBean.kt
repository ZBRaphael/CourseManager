package com.example.teacherstartrace.model

/**
 * ClassName:TeaInfoBean
 * Created bu ZhangBo at 2020/6/30
 * Describe:
 **/
data class TeaInfoBean(
    val teaTell: String,
    val teaAllClassHour: Int,
    val teaUsername: String
)