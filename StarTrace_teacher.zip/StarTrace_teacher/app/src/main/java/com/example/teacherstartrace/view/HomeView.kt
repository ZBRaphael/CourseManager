package com.example.teacherstartrace.view

/**
 * ClassName:HomeView
 * Created bu ZhangBo at 2020/6/20
 * Describe:负责home界面和presenter交互
 **/
interface HomeView {
}