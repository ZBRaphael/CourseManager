package com.example.teacherstartrace.model

/**
 * ClassName:StudentInfoBean
 * Created bu ZhangBo at 2020/6/28
 * Describe:
 **/
data class StuInfoBean(
    val stuRestHour: Int,
    val stuTell: String,
    val stuTotalHour: Int,
    val stuUsername: String
)