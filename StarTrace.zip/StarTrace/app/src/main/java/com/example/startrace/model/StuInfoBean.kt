package com.example.startrace.model

/**
 * ClassName:StuInfoBean
 * Created bu ZhangBo at 2020/6/26
 * Describe:
 **/
data class StuInfoBean(
    val stuRestHour: Int,
    val stuTell: String,
    val stuTotalHour: Int,
    val stuUsername: String,
    val interest: String
)