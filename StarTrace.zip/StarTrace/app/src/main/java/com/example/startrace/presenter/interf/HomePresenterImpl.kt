package com.example.startrace.presenter.interf

import com.example.startrace.presenter.impl.HomePresenter
import com.example.startrace.view.HomeView

/**
 * ClassName:HomePresenterImpl
 * Created bu ZhangBo at 2020/6/20
 * Describe:
 **/
class HomePresenterImpl(var homeView: HomeView):HomePresenter {

}