package com.example.startrace.model

/**
 * ClassName:LoginBean
 * Created bu ZhangBo at 2020/6/26
 * Describe:
 **/
data class LoginBean (
    val stuUsername:String,
    val stuPassword:String)